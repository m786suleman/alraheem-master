<?php 
    $total = 0;
    $index = 0;
?>
@if ($purchase)
    @foreach(session('purchase') as $id => $purchase)
    <?php 
        $total += $purchase['price'] * $purchase['quantity']; 
        $index++;
    ?>
        <tr>
            <td><a href="#" title="Delete" class="icon remove-from-purchase" data-id="{{ $id }}"><i class="fa fa-trash-o"></i></a></td>
            <td>{{ $purchase['e_name'] }}</td>
            <td>{{ $purchase['u_name'] }}</td> 
            <td>{{ $purchase['price'] }}</td>
            <td>{{ $purchase['quantity'] }}</td>
            <td >{{ $purchase['total'] }}</td>
        </tr>
    @endforeach
    <input type="hidden" id="total" name="total" data-id="{{ $total }}">
@else
    <tr>
        <td colspan="6" class="text-info text-center">No Item Added.</td>
    </tr>
@endif
