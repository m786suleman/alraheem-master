<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>TOOR HARDWARE STORE | POS - Point Of Sale</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('public/img/favicon.ico')}}">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/bootstrap.min.css')}}">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/font-awesome.min.css')}}">
    <!-- adminpro icon CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/adminpro-custon-icon.css')}}">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/meanmenu.min.css')}}">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/jquery.mCustomScrollbar.min.css')}}">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/animate.css')}}">
    <!-- jvectormap CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/jvectormap/jquery-jvectormap-2.0.3.css')}}">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/data-table/bootstrap-table.css')}}">
    <link rel="stylesheet" href="{{asset('public/css/data-table/bootstrap-editable.css')}}">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/normalize.css')}}">
    <!-- charts CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/c3.min.css')}}">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/style.css')}}">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="{{asset('public/css/responsive.css')}}">

    <link rel="stylesheet" href="{{asset('public/fm.selectator.jquery.css')}}"/>
    {{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css"/> --}}

    {{-- Select2 CDN --}}
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .selectator_selected_item_left{
            display: none;
        }
        .required{
            color: #ff0a05;
        }
    </style>
    <!-- modernizr JS
        ============================================ -->
        <script src="{{asset('public/js/vendor/jquery-1.11.3.min.js')}}"></script>
        <script src="{{asset('public/js/vendor/modernizr-2.8.3.min.js')}}"></script>
</head>

<body class="materialdesign">
    <!-- Header top area start-->
    <div class="wrapper-pro">
        <div class="left-sidebar-pro">
            @include('layout.left-sidebar')
        </div>
        <!-- Header top area start-->
        <div class="content-inner-all">
            @include('layout.header-top-area')
            <!-- Header top area end-->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="breadcome-heading">
                                            {{-- <form role="search" class="">
												<input type="text" placeholder="Search..." class="form-control">
												<a href=""><i class="fa fa-search"></i></a>
                                            </form> --}}
                                            @include('include.messages')
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="{{ route('dashboard') }}">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Purchase Form</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            @include('layout.mobile-menu')
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
            <div class="breadcome-area des-none mg-b-30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                            {{-- <form role="search" class="">
												<input type="text" placeholder="Search..." class="form-control">
												<a href=""><i class="fa fa-search"></i></a>
                                            </form> --}}
                                            @include('include.messages')
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Purchase Form</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- income order visit user Start -->
            <div class="income-order-visit-user-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="income-dashone-total income-monthly shadow-reset nt-mg-b-30">
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Purchase Form</h2>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <form method="POST">
                                        @csrf
                                        <div class="row">
                                            <div class="col-lg-4" id="show-vendors-section">
                                                
                                            </div>
                                            <div class="col-lg-1">
                                                <div class="form-group">
                                                    <label for="add_new_vendor">Add New</label>
                                                    <button type="button" id="add_new_vendor" class="btn btn-primary" data-toggle="modal" data-target="#myModalVendor"><i class="fa fa-plus"></i></button>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="current_date">Date</label>
                                                    <input type="date" class="form-control" name="current_date" id="current_date">
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="payment_method">Payment</label>
                                                    <select name="payment_method" id="payment_method" class="form-control">
                                                        <option value="cash">Cash</option>
                                                        <option value="credit">Credit</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="type">Type</label>
                                                    <select name="type" id="type" class="form-control">
                                                        <option value="purchase">Purchase</option>
                                                        {{-- <option value="credit">Credit</option> --}}
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-1">
                                                <div class="form-group">
                                                    <label for="opening_stock"></label>
                                                    <button style="margin-top: 5px;" tabindex="6" id="btn-add-in-list" class="btn btn-primary">Add in List</button>
                                                </div>
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label for="item">Items</label>
                                                    <select class="form-control" name="item" tabindex="2" id="item" accesskey="">
                                                        <option value="">Select Items</option>
                                                        @foreach ($items as $item)
                                                            <option value="{{ $item->id }}">{{ $item->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="quantity">Quantity</label>
                                                    <input type="text" class="form-control" value="1.0" tabindex="3" name="quantity" id="quantity">
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="purchase_rate">Purchase Rate</label>
                                                    <input type="number" class="form-control" value="0" tabindex="4" name="purchase_rate" id="purchase_rate">
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="sale_rate">Sale Rate</label>
                                                    <input type="number" class="form-control" value="0" tabindex="5" name="sale_rate" id="sale_rate">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-bottom: 10px;">
                                            <div class="col-lg-12">
                                                <table id="table1" data-toggle="table" data-pagination="false" data-search="false" data-show-columns="false" data-resizable="false" data-cookie="true" data-page-size="5" data-page-list="[5, 10, 15, 20, 25]" data-cookie-id-table="saveId" data-show-export="false">
                                                    <thead>
                                                        <tr>
                                                            <th data-field="state"></th>
                                                            <th data-field="item name">Item Name</th>
                                                            <th data-field="urdu name" >Urdu Name</th>
                                                            <th data-field="price" >Price</th>
                                                            <th data-field="quantity" >Quantity</th>
                                                            <th data-field="total" >Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="session-items">
                                                        
                                                    </tbody>
                                                </table>
                                                <div class="">
                                                    <div class="clear"></div>
                                                </div>
                                                <div class="row" style="margin-top: 20px;">
                                                    <div class="col-lg-4">
                                                        <div class="form-group">
                                                            <label for="total_bill">Total Bill</label>
                                                            <input type="number" class="form-control" value="" name="total_bill" id="total_bill">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-5"></div>
                                                    <div class="col-lg-3">
                                                        <div class="form-group">
                                                            <label for="vendor_previous_due">Vendor's Previous Balance</label>
                                                            <input type="number" class="form-control" value="0" name="vendor_previous_due" id="vendor_previous_due">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div class="form-group">
                                                            <label for="payable">Payable</label>
                                                            <input type="number" class="form-control" value="" name="payable" id="payable">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div class="form-group">
                                                            <label for="payment">Payment</label>
                                                            <input type="number" class="form-control" tabindex="6" value="" name="payment" id="payment">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-submit" tabindex="7">Submit</button>
                                        <button type="submit" class="btn btn-primary btn-reset" tabindex="8">Reset</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Start-->
    @include('layout.footer')
    <!-- Footer End-->

<!-- Customer Modal Start -->
<div id="myModalVendor" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h4 class="modal-title">Add New Vendor</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6">
                          <div class="form-group">
                              <label for="name">Name <span class="required">*</span></label>
                              <input type="text" name="name" class="form-control" id="account-name" autofocus required>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                              <label for="u_name">نام</label>
                              <input type="text" name="u_name" class="form-control" id="account-u_name" required>
                          </div>
                        </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                              <label for="address">Address <span class="required">*</span></label>
                              <input type="text" name="address" class="form-control" id="account-address" required>
                          </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                          <label for="phone">Phone <span class="required">*</span></label>
                          <input type="text" name="phone" class="form-control" id="account-phone" required>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                          <label for="type">Type</label>
                          <select name="type" id="account-type" class="form-control" required>
                            <option value="Vendor">Vendor</option>
                            <option value="Employee">Employee</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                          <label for="u_type">Type</label>
                          <select name="u_type" id="account-u_type" class="form-control" required>
                            <option value="وینڈر">وینڈر</option>
                            <option value="ملازم">ملازم</option>
                          </select>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="btn-customer-submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Customer Modal End -->

{{-- Save and print model start --}}
<div id="receivePaymentModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Payment Detail</h4>
        </div>
        <div class="modal-body" id="receivable-payment-body">
        </div>
      </div>
    </div>
</div>
{{-- Save and print model end --}}
    <!-- jquery
		============================================ -->
    <!-- bootstrap JS
		============================================ -->
    <script src="{{asset('public/js/bootstrap.min.js')}}"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="{{asset('public/js/jquery.meanmenu.js')}}"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="{{asset('public/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <!-- sticky JS
		============================================ -->
    <script src="{{asset('public/js/jquery.sticky.js')}}"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="{{asset('public/js/jquery.scrollUp.min.js')}}"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="{{asset('public/js/wow/wow.min.js')}}"></script>
    <!-- counterup JS
		============================================ -->
    <script src="{{asset('public/js/counterup/jquery.counterup.min.js')}}"></script>
    <script src="{{asset('public/js/counterup/waypoints.min.js')}}"></script>
    <script src="{{asset('public/js/counterup/counterup-active.js')}}"></script>
    <!-- jvectormap JS
		============================================ -->
    <script src="{{asset('public/js/jvectormap/jquery-jvectormap-2.0.2.min.js')}}"></script>
    <script src="{{asset('public/js/jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
    <script src="{{asset('public/js/jvectormap/jvectormap-active.js')}}"></script>
    <!-- peity JS
		============================================ -->
    <script src="{{asset('public/js/peity/jquery.peity.min.js')}}"></script>
    <script src="{{asset('public/js/peity/peity-active.js')}}"></script>
    <!-- sparkline JS
		============================================ -->
    <script src="{{asset('public/js/sparkline/jquery.sparkline.min.js')}}"></script>
    <script src="{{asset('public/js/sparkline/sparkline-active.js')}}"></script>
    <!-- flot JS
		============================================ -->
    <script src="{{asset('public/js/flot/Chart.min.js')}}"></script>
    <script src="{{asset('public/js/flot/dashtwo-flot-active.js')}}"></script>
    <!-- data table JS
		============================================ -->
    <script src="{{asset('public/js/data-table/bootstrap-table.js')}}"></script>
    <script src="{{asset('public/js/data-table/tableExport.js')}}"></script>
    <script src="{{asset('public/js/data-table/data-table-active.js')}}"></script>
    <script src="{{asset('public/js/data-table/bootstrap-table-editable.js')}}"></script>
    <script src="{{asset('public/js/data-table/bootstrap-editable.js')}}"></script>
    <script src="{{asset('public/js/data-table/bootstrap-table-resizable.js')}}"></script>
    <script src="{{asset('public/js/data-table/colResizable-1.5.source.js')}}"></script>
    <script src="{{asset('public/js/data-table/bootstrap-table-export.js')}}"></script>
    <!-- main JS
		============================================ -->
    <script src="{{asset('public/js/main.js')}}"></script>
    <script src="{{asset('public/fm.selectator.jquery.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script src="{{asset('public/print/jquery.printPage.js')}}"></script>
    {{-- <script src="{{asset('https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js')}}"></script> --}}
    <script>
        let today = new Date().toISOString().substr(0, 10);
        document.querySelector("#current_date").value = today;
        document.querySelector("#current_date").valueAsDate = new Date();
    </script>
    <script>
        $(document).ready(function(){
            var total = $('#total').attr("data-id");
            $.get('{{ route("purchase.get-session-items") }}', function(data){
                $('#session-items').empty().append(data);
                var total = $('#total').attr("data-id");
                document.querySelector("#total_bill").value = (total);
                document.querySelector("#payable").value = (total);
            });
            $.get('{{ route("purchase.get-vendors") }}', function(data){
                $('#show-vendors-section').empty().append(data);
            });

            $('#btn-print').click(function(e){
                $("#receivePaymentModal").modal('hide');
                $('#btn-print').printPage();
                // e.preventDefault();
            });
            $('#item').select2({
                placeholder: '--Select item--'
            });
            $('#customer').select2({
                placeholder: '--Select Vendor--'
            });

            $('#btn-add-in-list').click(function(e){
                e.preventDefault();
                var id = $("#item").val();
                var qty = $("#quantity").val();
                var purchase_rate = $("#purchase_rate").val();
                var sale_rate = $("#sale_rate").val();
                $.ajax({
                    type: "GET",
                    url: "{{ route('purchase.add-item-to-session') }}",
                    data: {
                            id:id,
                            qty:qty,
                            purchase_rate:purchase_rate,
                            sale_rate:sale_rate
                        },
                    success: function(data){
                        $("#item_name").select2('val', ' ');
                        $("#quantity").val("1.0");
                        $("#purchase_rate").val("0");
                        $("#sale_rate").val("0");
                        $('#session-items').empty().append(data);
                        var total = $('#total').attr("data-id");
                        document.querySelector("#total_bill").value = (total);
                    },
                    error: function(data){
                        alert('Select Any Item..');
                    }
                }); 
            });

            $(".btn-submit").click(function (e) {
                e.preventDefault();
                var customer_id = $('#customer').val();
                var current_date = $('#current_date').val();
                var payment_method = $('#payment_method').val();
                var type = $('#type').val();
                var quantity = $('#quantity').val();
                var purchase_rate = $('#purchase_rate').val();
                var sale_rate = $('#sale_rate').val();
                var total_bill = $('#total_bill').val();
                var vendor_previous_due = $('#vendor_previous_due').val();
                var payable = $('#payable').val();
                var payment = $('#payment').val();
                $.ajax({
                    url: "{{route('purchase.purchase-action')}}",
                    method: "post",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        customer_id: customer_id,
                        current_date:current_date,
                        payment_method:payment_method,
                        type:type,
                        quantity:quantity,
                        purchase_rate:purchase_rate,
                        sale_rate:sale_rate,
                        total_bill: total_bill,
                        vendor_previous_due:vendor_previous_due,
                        payable:payable,
                        payment:payment,
                        },
                    success:function(data){
                        alert(data);
                        window.location.reload();
                    }
                });
            });

            $("#session-items").on('click', '.remove-from-purchase', function (e) {
                e.preventDefault();
                var ele = $(this);
                if(confirm("Are you sure")) {
                    $.ajax({
                        url: "{{ route('purchase.delete-item-to-session') }}",
                        method: "DELETE",
                        data: {_token: '{{ csrf_token() }}', id: ele.attr("data-id")},
                        success: function(response){
                            $('#session-items').empty().append(response);
                            var total = $('#total').attr("data-id");
                            document.querySelector("#total_bill").value = (total);
                            document.querySelector("#payable").value = (total);
                        }
                    });
                }
            });

            $(".btn-reset").click(function (e) {
                e.preventDefault();
                var ele = $(this);
                if(confirm("Are you sure to reset page!")) {
                    $.ajax({
                        url: "{{ route('purchase.reset-session') }}",
                        method: "DELETE",
                        data: {_token: '{{ csrf_token() }}'},
                        success: function (response) {
                            // window.location.reload();
                            $('#session-items').empty().append(response);
                        }
                    });
                }
            });



            $("#item").change(function(){
                var id = $("#item").val();
                var qty = $("#quantity").val();
                $.ajax({
                    type: "GET",
                    url: "{{ route('sales.get-item-detail') }}",
                    data: {id:id},
                    success: function(data){
                        // alert(data);
                            document.querySelector("#purchase_rate").value = (data.price);
                    },
                    error: function(data){
                        alert('Error...!');
                    }
                });
            });

            $("#customer").change(function(){
                var id = $("#customer").val();
                $.ajax({
                    type: "GET",
                    url: "{{ route('sales.get-customer-detail') }}",
                    data: {id:id},
                    success: function(data){
                    },
                    error: function(data){
                        alert('Error...!');
                    }
                });
            });

            $('#btn-customer-submit').click(function(e){
                e.preventDefault();
                var name = $('#account-name').val();
                var u_name = $('#account-u_name').val();
                var address = $('#account-address').val();
                var phone = $('#account-phone').val();
                var type = $('#account-type').val();
                var u_type = $('#account-u_type').val();
                $.ajax({
                    url: "{{ route('purchase.add-vendor') }}",
                    type: "POST",   
                    data: {
                        "_token": "{{ csrf_token() }}",
                        name: name,
                        u_name: u_name,
                        address: address,
                        phone: phone,
                        type: type,
                        u_type: u_type,
                        },
                    success: function(data){
                        $("#myModalVendor").modal('hide');
                        $('#show-vendors-section').empty().append(data);
                    },
                    error: function(data){
                        alert('Error.....!');
                    }
                });
                
            });


        });
    </script>
</body>

</html>